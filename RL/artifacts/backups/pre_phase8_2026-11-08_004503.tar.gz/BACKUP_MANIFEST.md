# Model state backup

- Label: `pre_phase8`
- Created (UTC): `2026-11-08T00:45:03.472252+00:00`
- Archive: `pre_phase8_2026-11-08_004503.tar.gz`
- Repository: `C:\Users\danai\OneDrive\Documents\Smarthack\S-WAGG`
- Git branch: `feat/rl-agent`
- Git commit: `a95dd1bc8037b52bf15dd92efd0ac65eccb8a721`
- Working tree: `dirty`
- Python: `3.14.5`
- Platform: `Windows-11-10.0.26200-SP0`
- Farm checksum: `2fb404feebe8b7589b3043cbdbc316a4bd340342add18fbe8b4e0f4dc7cb688e`

## Agent / model summary

- `execution_steps`: `16`
- `fallback`: `rule_based`
- `model_id`: `deepseek-chat`
- `prompt_version`: `v1`
- `prompts_module_version`: `v1`
- `provider`: `deepseek`
- `replan_steps`: `16`

## Included files

| Path | Bytes | SHA-256 |
|---|---:|---|
| `.env.example` | 424 | `3d6cb3696e0b40947ca580d49021c101e33846c95f26023c1d1215010b5acb3d` |
| `artifacts/data/processed/data_card.md` | 2364 | `d17d6df48152c8772bff68ab4705c9203143767e8bbfc777e6d20ce889763227` |
| `artifacts/data/processed/dataset_meta.json` | 4461 | `82f9e109dac085c8a64a25a861663eac557351352ddfe04c493aa02a10f2b3e5` |
| `artifacts/data/processed/splits.json` | 173 | `c1aee01536a49b40fe37a0e557cea10c04f915ddf42c43d9fccb3e957c1f99ea` |
| `artifacts/data/processed/validation_report.json` | 990 | `cd08acc6b2ee7b5b44aa4c7cc284d8a16674a571352423de0049fa71399e4cd1` |
| `artifacts/models/pv/metrics.json` | 12942 | `2dc5c6f059600b16ff15d685537476d43dd8a857a5a857607ac1a8c52cb63b8c` |
| `artifacts/models/pv/model_card.md` | 1790 | `6f46346543ded7b5156b4de61619268fec7636438e95eadc52a292530b672714` |
| `artifacts/models/pv/predictions.csv` | 2958041 | `ad8274169cbc9a49be48232418f2e3d5576ae7da01179ea0bced729947974d54` |
| `artifacts/models/pv/pv_forecast_snapshots.csv` | 3251530 | `5b2119677c84b86604456ddaed88408d9691927167079fee7bf3d41935ff668d` |
| `artifacts/models/pv/pv_model.joblib` | 1470826 | `0777b4fb191891741314150ff599ecbe6789fcfb4dc4e6d7ee954483d80667d1` |
| `artifacts/reports/test/price_and_power.png` | 59710 | `6a675f4bf1a00a5050df392d6db73b93a8542d19e2954ca630c6b87211c1f1e6` |
| `artifacts/reports/test/report.md` | 7200 | `28a56767bd3c6fd6f786187f8b66b5bf9ddf8a02430d887e73a322bbcd86c050` |
| `artifacts/reports/test/results.csv` | 221071 | `bdcad4718d9c42f1225405db1d1d2a475da219a80ffa202ef64587643a58c46c` |
| `artifacts/reports/test/score_by_strategy.png` | 39042 | `a3863278e4a984a948b31039ec843d6162a6976605be8594c16a37e338671db6` |
| `artifacts/reports/test/soc_sample_day.png` | 94794 | `23ec247f062ae2fe92024e188ff84738c9b1f50c64c51bd990537bf0bb41866e` |
| `artifacts/reports/val/price_and_power.png` | 65867 | `84c84e441012124454c5ff6538b5d8b226940dd34f454df9721910ef84dda744` |
| `artifacts/reports/val/report.md` | 7170 | `dc27a307dc49e247cb4e435d1d5f269ebd7f951b21b9e3d53d2c3f159b4d2d17` |
| `artifacts/reports/val/results.csv` | 373117 | `b43e9e8889a17855f961f71fd79c5b915ae84cfff1c309bf3d45da9a3ea9e9b0` |
| `artifacts/reports/val/score_by_strategy.png` | 39708 | `4af219be59ae2e521e8c3fc405d2e42143b23d118edd3a460ab1c0dc8c972cf9` |
| `artifacts/reports/val/soc_sample_day.png` | 86557 | `c077becd0d04bae5190d9b4f20e3571d97f49ddd02a5bb8b86107927c5027582` |
| `configs/agent.yaml` | 276 | `219483dceb86d9d4ea23e2509a1e5c2a73e9772b7efe08fb7b05c0f1dc4fcb68` |
| `configs/env.yaml` | 403 | `e34bbf4241f148c900afacee792d2ca7ff0b4a22a8e4453d1eb3b433ea9d887e` |
| `configs/eval.yaml` | 346 | `6bb4db61b53b83e78e553cb873f055a4e403a7d701c22bd1de638eb92a8b74d8` |
| `configs/farm.example.yaml` | 478 | `375ca3d8f1f71b6f308f1560072a4a25d47f09ddba93e86fcd3b0333cc3ceeaf` |
| `configs/farm.yaml` | 402 | `b380f903f4ef62025745666d7846d1f8457665af51ba7a46e6dd9e8cd6a08cd5` |
| `configs/farm.yaml.sha256` | 65 | `fc0062cd881e4631d65c0014b7963cd5ca2b190a3821221c24ce33087fb2b623` |
| `configs/pv_model.yaml` | 460 | `4f3c1681528b9d5e7dbdc2d512c8cd5371450f97a435b1acefbb17ef27179a5c` |
| `docs/DEV_B_BRIEF.md` | 11439 | `680306b204c0c3c95d57e216b9904c5fc4fc26d9fe79b04634709d810e6d0925` |
| `IDEA.md` | 5512 | `ac9bde9bc04a3ffd3f4734ef595c8303662568ec587a57c65f962f34c741d6cf` |
| `PLAN.md` | 46923 | `261adb3e0858eda6f9356b49dbea53b1f500cca184d72db77ac023a006d7c298` |
| `PV_MODEL.md` | 19018 | `971e4ff598f277f5878f68b611da49b867a20954d45490525a84367d6aafd898` |
| `pyproject.toml` | 822 | `93b1b517a5d822c59c02f0844a89267790306a50ac9c5cc42f8f48b7a62d67a9` |
| `README.md` | 5405 | `5c1f61172b7513bd6d5fe62588199c23022ce13ea384b04b0b374e10298d8e08` |
| `scripts/backup_model_state.py` | 8391 | `70bf87d7db5a01cd0db6ee0803cb75660475e579655225182e40afa1ea27c1d1` |
| `scripts/build_dataset.py` | 14977 | `52c10408ffc59cda66fad568e87057e0b79b7856c435638d52ead8f23a6c4200` |
| `scripts/check_env.py` | 1261 | `9819e1356689a077e72d81e79bae6887fe195b5139f15bac22a808605d97c097` |
| `scripts/download_opcom.py` | 286 | `4573f073aee532bd2c18d72629cd0798e602bcbc3083ddc18ec9053e0cf7efd5` |
| `scripts/evaluate.py` | 7658 | `c7b29b43f1f77679339cf3d8f340e4cabc9c19f721ab14862145cd66f0d20f61` |
| `scripts/make_report.py` | 1274 | `6830c693c37133823286f9a595fc90a4c9d56eeebf7b58a247b8e57dcf87244d` |
| `scripts/train_pv.py` | 14546 | `3dc5ffb1b195f74dd494f1f8541288eeac07e523000028e3e50242f188bc8bb1` |
| `src/battery_rl/__init__.py` | 34 | `ec8787b3be7868853577fe5ff11181bb7f16de45a8f17a15f4513646d213ab87` |
| `src/battery_rl/agents/__init__.py` | 36 | `b778fb46ad831b75167e5ca1331ce2d33fea71a48dac011aaff75ee1a3b11855` |
| `src/battery_rl/agents/base.py` | 1372 | `2e367b4899d7645c68320ccca3dccdcccefe4de0a0bf7afd5504993fdf2d4dee` |
| `src/battery_rl/agents/llm.py` | 16680 | `9e30b7681665f6772503f8b156a1c19c27de8d93b108faa33d83bd5175ddda46` |
| `src/battery_rl/agents/prompts.py` | 4817 | `9b753bf9caa9b7b9d91dbd6dcf93f12631429f0776c5193244c9f827172c8c92` |
| `src/battery_rl/agents/schemas.py` | 14519 | `4815c8d98aa776b9402a8fc3c5d44cea1ca29f9986628d163452869b398a2275` |
| `src/battery_rl/agents/simulator.py` | 4813 | `a30b6433db4fa48c17536173f18e0177d140d3009f43389770974271160a3a88` |
| `src/battery_rl/agents/stub.py` | 1783 | `67978f5dd231db1fc709277f19b859dae361ef323595fa4d9a903321b1ddfaf7` |
| `src/battery_rl/agents/tools.py` | 12019 | `1fd7c231a8c939ea55e7f344346f890bbd4d87dfc43d78e2661500584eca1952` |
| `src/battery_rl/config.py` | 11828 | `30f87562c21ae87cb52cd94094a8782283f7cbe5d3834bb9f62554b72b4c00fc` |
| `src/battery_rl/credentials.py` | 2502 | `644092d6f8a99e503cc5044110914c235806af41273629941f10d253e9ec077a` |
| `src/battery_rl/data/__init__.py` | 30 | `217201aab6f9b9d727deb3ee0795a2a5dbc77a6d96d30f64d824ed82d98c6fce` |
| `src/battery_rl/data/dataset.py` | 14764 | `728f597d13aaebc29404446f46e184a14779a09283745f9d9de94e7a6897bc9b` |
| `src/battery_rl/data/entsoe.py` | 6312 | `d114c48ba62c9144ab19e701f24e0c8ad59ab7129dfde236299ba4203b10d686` |
| `src/battery_rl/data/forecasts.py` | 3069 | `6f47014f9c148325bf4920d56613957b0f551235501cc8455714d6617606e998` |
| `src/battery_rl/data/nwp.py` | 11338 | `39a8a7e37b35007fd6b09737e4025729fc4d0ececc4d592d6d8cb1ddf4014bcb` |
| `src/battery_rl/data/opcom.py` | 16808 | `0c5af92d92a245a416f3358606a2957272d1341df7ccc2a0168b71001a06b4f7` |
| `src/battery_rl/data/pv.py` | 17501 | `574bf2d200b2bf93db2d9c0db359855c9cdfde6bc04374d4372aabc04b990813` |
| `src/battery_rl/env/__init__.py` | 53 | `598bf2905f9786146e32acb9fcb96d18624922f4b91cbe8ccf1d9e333d3ec608` |
| `src/battery_rl/env/balance.py` | 5077 | `93a5aa1d973ba8ef37f8f3f1d0fe506da3b7ff1aa1b77a7d0461bf84d8858eba` |
| `src/battery_rl/env/battery.py` | 8266 | `b38fc6b02f95b5a29620bda5cf5ba19f2639a2cc6200a45a98ceb3c381f53c61` |
| `src/battery_rl/env/context.py` | 3930 | `1f6decc62d1e1d4130c2248d8f902f9daf14105828f582894f3942a766c156d5` |
| `src/battery_rl/env/env.py` | 15480 | `63b72d1dc4865637d681a031139326668939bb2cbef6fa93b8674477b122995b` |
| `src/battery_rl/eval/__init__.py` | 57 | `03b745f145866d4f0582a4b849718582859bfa8045b1e299de6205bc0ba2687a` |
| `src/battery_rl/eval/metrics.py` | 7162 | `3ea895e85f60d062f26f7d04db3098aef3b7fba8387eed8194f77b2ac72bc2af` |
| `src/battery_rl/eval/report.py` | 14306 | `d17502d63692bddc746c2350b4b77ef3932de4714497e368930978414ff1855c` |
| `src/battery_rl/eval/runner.py` | 11775 | `5b005935805012178cb9adfa1217e6ac57cac0bad151c3132027a26ac94add8a` |
| `src/battery_rl/models/__init__.py` | 42 | `df44a4886148b8a3fcea9e2445ca2b7ddbe66e5875aead5b10c32d1a5891effd` |
| `src/battery_rl/models/pv.py` | 12362 | `44fac85b3b8cc3a4b3c4490999a33f42af7f7cad6f90fe728c936caeda287e50` |
| `src/battery_rl/models/stub.py` | 1236 | `179e0532873510d6fa6b238d3c58b61cc53b4d20a428951481fa155be06e08f8` |
| `src/battery_rl/seeding.py` | 659 | `2387a689bb52dca6efeed344d5e635dcd1a40ca3bc1be86ef3b54d9b6848ca6a` |
| `src/battery_rl/strategies/__init__.py` | 52 | `085ba1bdab9685c64c0c5aa2548f6593a24901faa0ec2c7b8caeb46baa7d63f0` |
| `src/battery_rl/strategies/common.py` | 4465 | `2a744e3e813f5bd26dc44011f2abfbca62026d72d207fcb608ce817043f34016` |
| `src/battery_rl/strategies/idle.py` | 602 | `edf3c8893b52f819780860b0b7268a8371ed5e6543fa241effafb52ad4dda3e5` |
| `src/battery_rl/strategies/lp.py` | 4799 | `271c2182fac473b9bd65c74a7ee63b1ab16dedb099ef0ab09a8271cd151f856f` |
| `src/battery_rl/strategies/mpc.py` | 4691 | `25e669d6ad69ec1508e8db77be02daf88037e5203b7485b0223ed7d0ea8d9862` |
| `src/battery_rl/strategies/oracle_lp.py` | 684 | `08cec8abe24a28b4eba8a38cfc97e618a534ae3e878857e748390b313129338b` |
| `src/battery_rl/strategies/price_threshold.py` | 3378 | `fc624256ee716377aaa238b109642add1dbfdce70134f673f248345c21a75efc` |
| `src/battery_rl/strategies/rule_based.py` | 2462 | `7968b3dfc989ec8a752638a728f1d48ed58b4fd194e09ff2ea3d3172b9cf5688` |
| `TEAM_PLAN.md` | 18973 | `80204a57b99f18bc5ee86b0a0e76f56d23be8554a926b7b68dfcce47d70158cc` |
| `tests/fixtures/tiny_day.csv` | 12026 | `2d3c35f566e28b5fb1feba9580c4941229b955f769b4de7bee7dd43b0a395820` |
| `tests/fixtures/tiny_day_fall.csv` | 12523 | `29f818972298482c5eaa396c2d9d159d2c3a3471bb28fc31ff4d0d7b13c6fe4f` |
| `tests/fixtures/tiny_day_spring.csv` | 11530 | `45ef88836cc07df362fb296acc3b4978e07bcd5c01dc6eee7923db2b7df913d5` |
| `tests/test_balance.py` | 6914 | `b36e8c95f1b6c81a009cbe3a34082266b6a8635de5d9de0a0ea41b4d5f621216` |
| `tests/test_battery.py` | 10543 | `c177854b5b44ff81c924f47100a54a57329324e30659c41d5e85dc3bb183c289` |
| `tests/test_config.py` | 4969 | `d121e5410232350acd2b0f3e1784335290454d01cd9d85ae51540d2695a990f7` |
| `tests/test_context.py` | 8597 | `f3ebe43977c096083c8ae5492e58bb8e9afa6ed146515271decdc1212662a474` |
| `tests/test_credentials.py` | 2947 | `c4385ba0268a54ccc41c74c305c889673d9a1dfa1309255d96d3ae9188a5d3aa` |
| `tests/test_data_contract.py` | 15121 | `1c1fb64afe146f2fc2c17c076a3f6f206d863534b02bb52bbd3ab2dbf0d398f6` |
| `tests/test_env.py` | 13772 | `82559332bfefcd458def5675f4f7298e02de712b7d071a19d4c3ca3d8e671c68` |
| `tests/test_llm_agent.py` | 10771 | `c7fe528e8166fb8af4fdde9097ddec001522d6e215242260b21fecd5bc3f5065` |
| `tests/test_llm_integration.py` | 3098 | `645c8fbc81ad389ed7617237e28d8b8165dab4dc97495b8823af757567439d48` |
| `tests/test_metrics.py` | 8530 | `928b07d0d845c25d85716b58bed5fee66865177bd87089e510e68485a4dc8aed` |
| `tests/test_mpc.py` | 6540 | `6ec849decc7305e731e0e91a32821e11da5dfd35d27d7e310e10a1e36a3c1121` |
| `tests/test_opcom.py` | 3985 | `0d4efcb0dae8f733cd61277e3048fc3d4698be402a9d7996f58a2cc8f475e30d` |
| `tests/test_pv_model.py` | 8635 | `7a3abe1e1295774df7975af0966b11b8d17ae39361c0457310f049fcbe2cb30b` |
| `tests/test_report.py` | 5414 | `3405221fd96176a0607ed73a181de5ed403d6b062d17bb150f3476fd8866ccaf` |
| `tests/test_runner.py` | 7338 | `03129ee83175fa014f5f022608a3af45826788d32fc67ebe56a1fd0272c85a44` |
| `tests/test_schemas.py` | 14476 | `736a82e69f9a7b99e1f3637aadc5b58956d18c50a8c969396b56f8cc9828b17c` |
| `tests/test_strategies.py` | 7557 | `7e4bf223f34c4124c4db2cf7aa32972b381799d4a34778537d6efa3438b36409` |

## Excluded on purpose

- `RL/.env` (secret API key), `.env` files anywhere, virtual environments,
  caches, `__pycache__`, raw data downloads, and the large processed CSVs.

## Restore

```powershell
cd RL
tar -xzf artifacts/backups/pre_phase8_2026-11-08_004503.tar.gz -C .
```

The archive paths are relative to `RL/`, so extracting over the checkout
restores the snapshotted files. Verify the archive checksum first:

```powershell
Get-FileHash artifacts/backups/pre_phase8_2026-11-08_004503.tar.gz -Algorithm SHA256
```
